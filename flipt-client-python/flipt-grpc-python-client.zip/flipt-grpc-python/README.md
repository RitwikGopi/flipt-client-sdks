# Flipt Python gRPC Client

A Python gRPC client for Flipt server-side feature flag evaluation.

## Overview

This gRPC client allows you to evaluate feature flags by communicating directly with a Flipt server via gRPC. Unlike the main `FliptClient` which performs client-side evaluation using a local FFI engine, this client makes network calls to the Flipt server for each evaluation.

## Installation

```bash
pip install -r requirements.txt
```

## Quick Start

```python
from flipt_grpc import FliptGrpcClient, GrpcClientOptions

# Create a client
client = FliptGrpcClient(
    opts=GrpcClientOptions(
        address="localhost:9000",
        namespace_key="default"
    )
)

# Evaluate a boolean flag
result = client.evaluate_boolean(
    flag_key="my-feature",
    entity_id="user-123",
    context={"region": "us-west"}
)

print(f"Feature enabled: {result.enabled}")

# List all flags
flags = client.list_flags()
print(f"Total flags: {flags.total_count}")
for flag in flags.flags:
    print(f"  - {flag.key}: {flag.name}")

client.close()
```

## Features

- **evaluate_boolean()** - Evaluate boolean flags
- **evaluate_variant()** - Evaluate variant flags
- **evaluate_batch()** - Batch evaluate multiple flags
- **list_flags()** - List all flags with pagination support

## Important Notes

The gRPC client uses **two separate gRPC services**:

1. **`flipt.evaluation.EvaluationService`** - For flag evaluations
   - Boolean()
   - Variant()
   - Batch()

2. **`flipt.Flipt`** - For management operations
   - ListFlags()

This matches the Flipt server's gRPC API structure.

## Documentation

- **README.md** - This file
- **INSTALL.md** - Installation guide
- **DEPENDENCIES.md** - Dependency information
- **examples/grpc_example.py** - Comprehensive examples (6 examples)

## License

MIT License - Part of the Flipt Client SDKs project.
