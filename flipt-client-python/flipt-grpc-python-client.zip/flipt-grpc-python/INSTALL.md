# Installation Guide

## Quick Install

```bash
# Extract the package
tar -xzf flipt-grpc-python-client.tar.gz
cd flipt-grpc-python

# Install dependencies
pip install -r requirements.txt

# Verify installation
python -c "from flipt_grpc import FliptGrpcClient; print('✅ Success!')"
```

## Run Examples

```bash
python examples/grpc_example.py
```

## Run Tests

```bash
pytest tests/test_grpc_client.py -v
```
