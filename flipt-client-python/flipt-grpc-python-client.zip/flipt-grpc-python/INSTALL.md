# Installation Guide

This guide walks you through installing and setting up the Flipt Python gRPC client.

## Prerequisites

- Python 3.8 or higher
- pip (Python package manager)
- A running Flipt server with gRPC enabled

## Installation

### Step 1: Extract the Package

```bash
# If you have the tar.gz file
tar -xzf flipt-grpc-python-client.tar.gz
cd flipt-grpc-python

# If you have the zip file
unzip flipt-grpc-python-client.zip
cd flipt-grpc-python
```

### Step 2: Install Dependencies

```bash
pip install -r requirements.txt
```

This will install:
- `grpcio>=1.60.0` - gRPC runtime
- `protobuf>=4.21.0` - Protocol buffers
- `grpcio-tools>=1.60.0` - For proto code generation (dev only)
- `pytest>=8.2.0` - For running tests (dev only)

### Step 3: Verify Installation

```python
# test_install.py
from flipt_grpc import FliptGrpcClient, GrpcClientOptions

try:
    client = FliptGrpcClient(opts=GrpcClientOptions(address="localhost:9000"))
    print("✅ Flipt gRPC client installed successfully!")
    client.close()
except ImportError as e:
    print(f"❌ Installation failed: {e}")
```

Run the test:
```bash
python test_install.py
```

## Integration Options

### Option 1: Standalone Usage

Copy the `flipt_grpc` directory to your project:

```bash
cp -r flipt_grpc /path/to/your/project/
```

Then use it:
```python
from flipt_grpc import FliptGrpcClient, GrpcClientOptions
```

### Option 2: Install as Package

Create a `setup.py` file:

```python
from setuptools import setup, find_packages

setup(
    name="flipt-grpc",
    version="1.0.0",
    packages=find_packages(),
    install_requires=[
        "grpcio>=1.60.0",
        "protobuf>=4.21.0",
    ],
)
```

Install in development mode:
```bash
pip install -e .
```

### Option 3: Add to PYTHONPATH

```bash
export PYTHONPATH=$PYTHONPATH:/path/to/flipt-grpc-python
```

## Set Up Flipt Server

Ensure your Flipt server has gRPC enabled:

### 1. Check Configuration

Edit your `flipt.yml`:
```yaml
server:
  grpc:
    enabled: true
    port: 9000
```

### 2. Start Flipt Server

```bash
flipt
```

### 3. Verify gRPC is Running

```bash
# Check if port 9000 is listening
netstat -an | grep 9000
# or
lsof -i :9000
```

## Test Connection

```python
# test_connection.py
from flipt_grpc import FliptGrpcClient, GrpcClientOptions
import grpc

try:
    client = FliptGrpcClient(opts=GrpcClientOptions(address="localhost:9000"))
    result = client.evaluate_boolean(
        flag_key="test-flag",
        entity_id="test-user"
    )
    print("✅ Successfully connected to Flipt server!")
except grpc.RpcError as e:
    if e.code() == grpc.StatusCode.NOT_FOUND:
        print("✅ Connected (flag not found is normal)")
    elif e.code() == grpc.StatusCode.UNAVAILABLE:
        print("❌ Cannot connect to Flipt server")
    else:
        print(f"❌ Error: {e.code()} - {e.details()}")
finally:
    client.close()
```

## Run Examples

```bash
python examples/grpc_example.py
```

## Run Tests

```bash
pytest tests/test_grpc_client.py -v
```

## Common Issues

### ModuleNotFoundError: No module named 'grpc'

**Solution:**
```bash
pip install grpcio
```

### ImportError: cannot import name 'FliptGrpcClient'

**Solution:** Make sure you're in the correct directory and all `__init__.py` files exist:
```bash
ls -la flipt_grpc/__init__.py
ls -la flipt_grpc/flipt/__init__.py
ls -la flipt_grpc/flipt/evaluation/__init__.py
```

### grpc.RpcError: StatusCode.UNAVAILABLE

**Solution:** Flipt server is not running
```bash
flipt  # Start the server
```

### grpc.RpcError: StatusCode.UNAUTHENTICATED

**Solution:** Add authentication token
```python
client = FliptGrpcClient(
    opts=GrpcClientOptions(
        address="localhost:9000",
        client_token="your-client-token"
    )
)
```

## Environment Variables

Configure using environment variables:

```python
# config.py
import os
from flipt_grpc import GrpcClientOptions

def get_options():
    return GrpcClientOptions(
        address=os.getenv("FLIPT_GRPC_ADDRESS", "localhost:9000"),
        namespace_key=os.getenv("FLIPT_NAMESPACE", "default"),
        environment_key=os.getenv("FLIPT_ENVIRONMENT", "default"),
        secure=os.getenv("FLIPT_SECURE", "false").lower() == "true",
        client_token=os.getenv("FLIPT_CLIENT_TOKEN")
    )
```

```bash
# .env
FLIPT_GRPC_ADDRESS=localhost:9000
FLIPT_NAMESPACE=production
FLIPT_ENVIRONMENT=prod
FLIPT_SECURE=false
FLIPT_CLIENT_TOKEN=your-token
```

## Next Steps

1. Read `README.md` for usage examples
2. Check `examples/grpc_example.py` for comprehensive examples
3. See `flipt_grpc/README.md` for detailed API documentation
4. Review `DEPENDENCIES.md` for integration details

## Support

- Flipt Documentation: https://docs.flipt.io
- Flipt GitHub: https://github.com/flipt-io/flipt
- gRPC Python Docs: https://grpc.io/docs/languages/python/
