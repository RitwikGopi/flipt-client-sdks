# Dependencies

## Runtime
- grpcio >= 1.60.0
- protobuf >= 4.21.0

## Development
- grpcio-tools >= 1.60.0
- pytest >= 8.2.0

## Python Compatibility
- Minimum: Python 3.8
- Recommended: Python 3.9+
