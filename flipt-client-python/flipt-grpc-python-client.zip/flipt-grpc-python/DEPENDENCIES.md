# Dependencies

This document outlines the dependencies required for the Flipt Python gRPC client.

## Runtime Dependencies

### Required

- **grpcio >= 1.60.0** - gRPC runtime library
  - Handles network communication with the Flipt server
  - Provides channel management and connection handling

- **protobuf >= 4.21.0** - Protocol buffers library
  - Serialization/deserialization of messages
  - Required for all gRPC communication

### Installation

```bash
pip install grpcio>=1.60.0 protobuf>=4.21.0
```

Or use the provided requirements.txt:
```bash
pip install -r requirements.txt
```

## Development Dependencies

### Optional (for development)

- **grpcio-tools >= 1.60.0** - Proto code generation tools
  - Only needed if regenerating proto files
  - Not required for using the client

- **pytest >= 8.2.0** - Testing framework
  - Only needed for running tests
  - Not required for using the client

### Installation

```bash
pip install grpcio-tools>=1.60.0 pytest>=8.2.0
```

## Integration with flipt-client Package

If you're integrating this gRPC client into the main `flipt-client` package, update `pyproject.toml`:

### Add to Runtime Dependencies

```toml
[tool.poetry.dependencies]
python = ">=3.8,<4.0"
pydantic = ">=1.10,<3.0"
packaging = ">=24,<26"
grpcio = ">=1.60.0"      # NEW
protobuf = ">=4.21.0"    # NEW
```

### Add to Development Dependencies

```toml
[tool.poetry.group.dev.dependencies]
black = ">=23.11,<26.0"
pytest = "^8.2.0"
grpcio-tools = ">=1.60.0"  # NEW
```

### Install with Poetry

```bash
poetry install
```

## Python Version Requirements

- **Minimum**: Python 3.8
- **Recommended**: Python 3.9+
- **Tested**: Python 3.8, 3.9, 3.10, 3.11, 3.12

## Platform Compatibility

The gRPC client is pure Python and works on all platforms:

- ✅ Linux (all architectures)
- ✅ macOS (Intel and Apple Silicon)
- ✅ Windows (x86_64)
- ✅ Any platform where Python and gRPC are available

Unlike the FFI client, there are no platform-specific binary dependencies.

## Version Compatibility

### grpcio

- **Minimum**: 1.60.0
- **Tested**: 1.60.0 - 1.76.0
- **Latest**: Compatible with all 1.x versions

### protobuf

- **Minimum**: 4.21.0
- **Tested**: 4.21.0 - 6.x
- **Latest**: Compatible with 4.x, 5.x, and 6.x

## Dependency Tree

```
flipt-grpc
├── grpcio>=1.60.0
│   └── typing-extensions~=4.12
└── protobuf>=4.21.0
```

## Optional Features

### TLS/SSL Support

No additional dependencies required - included with `grpcio`.

### Authentication

No additional dependencies required - uses gRPC metadata.

## Troubleshooting

### Version Conflicts

If you encounter version conflicts:

```bash
# Check installed versions
pip list | grep grpc
pip list | grep protobuf

# Upgrade if needed
pip install --upgrade grpcio protobuf
```

### Binary Compatibility

If you get binary compatibility errors:

```bash
# Rebuild wheels for your platform
pip install --no-binary :all: grpcio
```

### Memory Issues

For constrained environments:

```bash
# Install without development dependencies
pip install grpcio protobuf
```

## Comparison with FFI Client Dependencies

| Aspect | gRPC Client | FFI Client |
|--------|-------------|------------|
| Python Packages | grpcio, protobuf | pydantic, packaging |
| Binary Dependencies | None | libfliptengine (platform-specific) |
| Installation Size | ~10 MB | ~5-15 MB (varies by platform) |
| Platform Support | All platforms | Specific architectures only |
| Build Requirements | None | May need compilers |

## CI/CD Considerations

### Docker

```dockerfile
FROM python:3.11-slim

WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY flipt_grpc /app/flipt_grpc
```

### Requirements Pinning

For production, pin exact versions:

```txt
# requirements-prod.txt
grpcio==1.76.0
protobuf==6.33.1
```

### Testing Matrix

Recommended test matrix:

- Python 3.8 + grpcio 1.60.0 + protobuf 4.21.0
- Python 3.11 + grpcio 1.76.0 + protobuf 6.33.1
- Python 3.12 + latest grpcio + latest protobuf

## License

All dependencies are open source:

- grpcio: Apache License 2.0
- protobuf: BSD-3-Clause

Compatible with MIT license of this project.
