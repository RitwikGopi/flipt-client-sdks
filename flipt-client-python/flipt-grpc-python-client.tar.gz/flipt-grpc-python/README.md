# Flipt Python gRPC Client

A Python gRPC client for Flipt server-side feature flag evaluation.

## Overview

This gRPC client allows you to evaluate feature flags by communicating directly with a Flipt server via gRPC. Unlike the main `FliptClient` which performs client-side evaluation using a local FFI engine, this client makes network calls to the Flipt server for each evaluation.

## When to Use

**Use the gRPC client when:**
- You want server-side evaluation for centralized control
- You need real-time flag updates without polling
- You prefer not to bundle the FFI engine with your application
- You're building microservices that can easily communicate with a central Flipt server

**Use the FFI client (FliptClient) when:**
- You need offline evaluation capabilities
- You want to minimize network latency
- You need to evaluate flags in environments without reliable network connectivity
- You want to reduce load on your Flipt server

## Installation

```bash
# Install dependencies
pip install -r requirements.txt
```

## Quick Start

```python
from flipt_grpc import FliptGrpcClient, GrpcClientOptions

# Create a client
client = FliptGrpcClient(
    opts=GrpcClientOptions(
        address="localhost:9000",
        namespace_key="default",
        environment_key="production"
    )
)

# Evaluate a boolean flag
result = client.evaluate_boolean(
    flag_key="my-feature",
    entity_id="user-123",
    context={"region": "us-west"}
)

print(f"Feature enabled: {result.enabled}")

# List all flags
flags = client.list_flags()
print(f"Total flags: {flags.total_count}")
for flag in flags.flags:
    print(f"  - {flag.key}: {flag.name}")

# Always close the client
client.close()
```

## Features

### Evaluation Methods

- **evaluate_boolean()** - Evaluate boolean flags
- **evaluate_variant()** - Evaluate variant flags
- **evaluate_batch()** - Batch evaluate multiple flags
- **list_flags()** - List all flags with pagination support

### Configuration Options (GrpcClientOptions)

- `address` (str): The address of the Flipt gRPC server (default: "localhost:9000")
- `namespace_key` (str): The namespace to use for evaluations (default: "default")
- `environment_key` (str): The environment to use for evaluations (default: "default")
- `secure` (bool): Whether to use TLS/SSL for the connection (default: False)
- `client_token` (str, optional): Client token for authentication
- `ssl_cert_path` (str, optional): Path to SSL certificate for secure connections

## Usage Examples

### List Flags

```python
# List all flags
result = client.list_flags()

print(f"Total flags: {result.total_count}")
for flag in result.flags:
    print(f"Flag: {flag.key}")
    print(f"  Name: {flag.name}")
    print(f"  Enabled: {flag.enabled}")
    print(f"  Type: {'Boolean' if flag.type == 1 else 'Variant'}")
    if flag.variants:
        print(f"  Variants: {', '.join([v.key for v in flag.variants])}")

# With pagination
result = client.list_flags(limit=10, page_token="token_here")
if result.next_page_token:
    next_page = client.list_flags(page_token=result.next_page_token)
```

### Boolean Flag Evaluation

```python
result = client.evaluate_boolean(
    flag_key="enable-feature-x",
    entity_id="user-456",
    context={"plan": "premium", "region": "us-east"}
)

print(f"Enabled: {result.enabled}")
print(f"Reason: {result.reason}")
```

### Variant Flag Evaluation

```python
result = client.evaluate_variant(
    flag_key="color-theme",
    entity_id="user-789",
    context={"device": "mobile"}
)

print(f"Variant: {result.variant_key}")
print(f"Attachment: {result.variant_attachment}")
```

### Batch Evaluation

```python
batch_requests = [
    {"flag_key": "feature-a", "entity_id": "user-123", "context": {"role": "admin"}},
    {"flag_key": "feature-b", "entity_id": "user-123", "context": {"role": "admin"}}
]

result = client.evaluate_batch(requests=batch_requests)

for response in result.responses:
    if response.HasField("boolean_response"):
        print(f"{response.boolean_response.flag_key}: {response.boolean_response.enabled}")
```

### Context Manager

```python
with FliptGrpcClient(opts=GrpcClientOptions(address="localhost:9000")) as client:
    result = client.evaluate_boolean("my-flag", "user-123")
    print(result.enabled)
```

### Secure Connection

```python
client = FliptGrpcClient(
    opts=GrpcClientOptions(
        address="flipt.example.com:443",
        secure=True,
        client_token="your-client-token"
    )
)
```

## Package Contents

```
flipt-grpc-python/
├── README.md                  # This file
├── INSTALL.md                 # Installation guide
├── DEPENDENCIES.md            # Integration details
├── requirements.txt           # Python dependencies
├── flipt_grpc/               # Main client library
├── proto/                     # Proto definitions
├── examples/                  # Usage examples
└── tests/                     # Unit tests
```

## Running Tests

```bash
pip install pytest
pytest tests/test_grpc_client.py -v
```

## Server Configuration

Make sure your Flipt server has gRPC enabled:

```yaml
server:
  grpc:
    enabled: true
    port: 9000
```

## Documentation

- **README.md** - This file, overview and quick start
- **INSTALL.md** - Detailed installation instructions
- **DEPENDENCIES.md** - Integration with flipt-client package
- **flipt_grpc/README.md** - Detailed API documentation
- **examples/grpc_example.py** - Comprehensive usage examples (6 examples)

## License

MIT License - This code is part of the Flipt Client SDKs project.
