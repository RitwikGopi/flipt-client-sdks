# Installation Guide

This guide walks you through installing and setting up the Flipt Python gRPC client.

## Prerequisites

- Python 3.8 or higher
- pip (Python package manager)
- A running Flipt server with gRPC enabled

## Installation

### Step 1: Extract the Package

```bash
# If you have the tar.gz file
tar -xzf flipt-grpc-python-client.tar.gz
cd flipt-grpc-python

# If you have the zip file
unzip flipt-grpc-python-client.zip
cd flipt-grpc-python
```

### Step 2: Install Dependencies

```bash
pip install -r requirements.txt
```

This will install:
- `grpcio>=1.60.0` - gRPC runtime
- `protobuf>=4.21.0` - Protocol buffers
- `grpcio-tools>=1.60.0` - For proto code generation (dev only)
- `pytest>=8.2.0` - For running tests (dev only)

### Step 3: Verify Installation

```python
# test_install.py
from flipt_grpc import FliptGrpcClient, GrpcClientOptions

try:
    client = FliptGrpcClient(opts=GrpcClientOptions(address="localhost:9000"))
    print("✅ Flipt gRPC client installed successfully!")
    client.close()
except ImportError as e:
    print(f"❌ Installation failed: {e}")
```

## Run Examples

```bash
python examples/grpc_example.py
```

## Run Tests

```bash
pytest tests/test_grpc_client.py -v
```

## Next Steps

1. Read `README.md` for usage examples
2. Check `examples/grpc_example.py` for comprehensive examples
3. See `flipt_grpc/README.md` for detailed API documentation
4. Review `DEPENDENCIES.md` for integration details
