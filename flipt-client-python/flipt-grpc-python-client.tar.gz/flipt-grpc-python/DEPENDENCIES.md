# Dependencies

## Runtime Dependencies

- **grpcio >= 1.60.0** - gRPC runtime library
- **protobuf >= 4.21.0** - Protocol buffers library

## Development Dependencies

- **grpcio-tools >= 1.60.0** - Proto code generation tools
- **pytest >= 8.2.0** - Testing framework

## Installation

```bash
pip install -r requirements.txt
```

## Python Version Requirements

- **Minimum**: Python 3.8
- **Recommended**: Python 3.9+
- **Tested**: Python 3.8, 3.9, 3.10, 3.11, 3.12

## Platform Compatibility

The gRPC client is pure Python and works on all platforms:
- Linux (all architectures)
- macOS (Intel and Apple Silicon)
- Windows (x86_64)
- Any platform where Python and gRPC are available
